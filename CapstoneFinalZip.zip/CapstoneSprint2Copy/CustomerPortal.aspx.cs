﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class CustomerPortal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = "";
            //Label2.Text = "";

            //Used to check if the Page is loaded first time
            if (!IsPostBack)
            {
                ListOfData();
            }
        }

        //protected void btnCreateFolder_Click(object sender, EventArgs e)
        //{
        //    string createFolder = Server.MapPath(string.Format("~/{0}/", txtFolderName.Text));
        //    if (!Directory.Exists(createFolder))
        //    {
        //        Directory.CreateDirectory(createFolder);
        //        Label1.Text = "Folder " + txtFolderName.Text + " Is Created Successfully";
        //        Label1.ForeColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        Label1.Text = "Folder " + txtFolderName.Text + " Already Exists";
        //        Label1.ForeColor = System.Drawing.Color.Red;
        //    }
        //}

        //protected void btnUpload_Click(object sender, EventArgs e)
        //{
        //    string imgext = Path.GetExtension(FileUpload1.FileName);

        //    if(imgext == ".jpg" || imgext == ".png" || imgext == ".gif")
        //    {
        //        foreach (HttpPostedFile selectedimgs in FileUpload1.PostedFiles)
        //        {
        //            string imgNames = Path.GetFileName(selectedimgs.FileName);
        //            selectedimgs.SaveAs(Server.MapPath("/" + txtFolderName.Text + "/") + imgNames);
        //        }
        //        Label2.Text = string.Format("{0} Images are saved into '" + txtFolderName.Text + "'Successfully !", FileUpload1.PostedFiles.Count);
        //        Label2.ForeColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        Label2.Text = "Only the .jpg, .png, .gif files are allowed";
        //        Label2.ForeColor = System.Drawing.Color.Green;
        //    }
        //}

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            // For uploading a file
            if (FileUpload.HasFile)
            {
                string FileName = FileUpload.FileName;

                // File is saved  
                FileUpload.PostedFile.SaveAs(Server.MapPath("~/MyUploads/") + FileName);
            }
            ListOfData();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
            //Used to fetch the file from the folder
            Response.TransmitFile(Server.MapPath("~/MyUploads/") + e.CommandArgument);
            Response.End();
        }

        private void ListOfData()
        {
            // Create a datatable
            DataTable dt = new DataTable();
            // Add Columns with the Same name as the Eval Expression and the DataField of the Gridview  
            dt.Columns.Add("File");
            dt.Columns.Add("Size");
            dt.Columns.Add("Type");
            // Loop through Each file available in the folder  
            foreach (string str in Directory.GetFiles(Server.MapPath("~/MyUploads")))
            {
                FileInfo fileinfo = new FileInfo(str);
                //Get the name of the File  
                string filename = fileinfo.Name;
                string filesize = (fileinfo.Length / 1024).ToString();
                string filetype = GetFileTypeByFileExtension(fileinfo.Extension);
                // Add Rows to the DataTable  
                dt.Rows.Add(filename, filesize, filetype);
            }
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        private string GetFileTypeByFileExtension(string fileExtension)
        {
            switch (fileExtension.ToLower())
            {
                case ".doc":
                case ".docx":
                    return "Microsoft Word Document";
                case ".xls":
                case ".xlsx":
                    return "Microsoft Excel Document";
                case ".txt":
                    return "Text File";
                case ".png":
                case ".jpg":
                    return "Windows Image file";
                default:
                    return "Unknown file type";
            }
        }

        protected void backBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerLogin.aspx");
        }
    }
}