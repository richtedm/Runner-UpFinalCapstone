﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class MovePreAssessment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Page.PreviousPage != null)
            {
                string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM MovePreAssessment INNER JOIN Customer ON MovePreAssessment.CustomerID = Customer.CustomerID WHERE MovePreAssessment.CustomerID = @id", con);

                SqlCommand cmd2 = new SqlCommand("SELECT Customer.Note FROM Customer WHERE CustomerID = @id", con);

                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                txtName.Text = Session["CustomerName"].ToString();
                txtPhone.Text = Session["PhoneNumber"].ToString();
                txtEmail.Text = Session["Email"].ToString();
                txtDate.Text = Session["InitialContactDate"].ToString();

                cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                cmd2.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                
                while (dr.Read()) 
                {
                    txtMoveDate.Text = dr["OutDate"].ToString();
                    txtEarlyDate.Text = dr["EarlyDate"].ToString();
                    txtLateDate.Text = dr["LateDate"].ToString();
                    txtToAdd.Text = dr["DestAdd"].ToString();
                    txtToCity.Text = dr["DestCity"].ToString();
                    ddlState.SelectedItem.Text = dr["DestSt"].ToString();
                    txtToZip.Text = dr["DestZip"].ToString();
                    if (dr["MLS"].Equals("Yes"))
                    {
                        cbMLS.Checked = true;
                    }
                    else 
                    {
                        cbMLS.Checked = false;
                    }

                    if (dr["Photo"].Equals("Yes"))
                    {
                        cbPhoto.Checked = true;
                    }
                    else
                    {
                        cbPhoto.Checked = false;
                    }

                    if (dr["Packing"].Equals("Yes"))
                    {
                        cbPacking.Checked = true;
                    }
                    else
                    {
                        cbPacking.Checked = false;
                    }

                    if (dr["Trash"].Equals("Yes"))
                    {
                        cbTrash.Checked = true;
                        tbTD.Text = dr["TDesc"].ToString();
                    }
                    else
                    {
                        cbTrash.Checked = false;
                    }
                }

                dr.Close();
                SqlDataReader dr2 = cmd2.ExecuteReader();

                // Data reader from SQL Queries
                while (dr2.Read())
                {
                    txtNoteContents.Text = Server.HtmlDecode(dr2["Note"].ToString());
                    txtNoteContents.Text = txtNoteContents.Text.Replace("<p>", "");
                }


                dr2.Close();
                con.Close();



            }

        }


        protected void Trash_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTrash.Checked == true)
            {
                trashdiv.Visible = true;
            }
            else { trashdiv.Visible = false; }
        }
        protected void btPart2_Click(object sender, EventArgs e)
        {
            String state = ddlState.SelectedValue;
            String MLS = "No";
            String Photo = "No";
            String Packing = "No";
            String Trash = "No";
            if (cbMLS.Checked)
            {
                MLS = "Yes";
            }
            if (cbPhoto.Checked)
            {
                Photo = "Yes";
            }
            if (cbPacking.Checked)
            {
                Packing = "Yes";
            }
            if (cbTrash.Checked)
            {
                Trash = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "Insert into MovePreAssessment(OutDate, EarlyDate, LateDate, DestAdd, DestCity, DestSt, DestZip, MLS, Photo, Packing, Trash, TDesc, CustomerID) VALUES(@OutDate, @EarlyDate, @LateDate, @DestAdd, @DestCity, @DestSt, @DestZip, @MLS, @Photo, @Packing, @Trash, @TDesc, @id)";
            String query2 = "UPDATE Customer SET Note = @note Where CustomerID = " + hiddenCustomerID.Text + "";

            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@OutDate", HttpUtility.HtmlEncode(txtMoveDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@EarlyDate", HttpUtility.HtmlEncode(txtEarlyDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@LateDate", HttpUtility.HtmlEncode(txtLateDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@DestAdd", HttpUtility.HtmlEncode(txtToAdd.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@DestCity", HttpUtility.HtmlEncode(txtToCity.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@DestSt", HttpUtility.HtmlEncode(state));
            adapter.InsertCommand.Parameters.AddWithValue("@DestZip", HttpUtility.HtmlEncode(txtToZip.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@MLS", HttpUtility.HtmlEncode(MLS));
            adapter.InsertCommand.Parameters.AddWithValue("@Photo", HttpUtility.HtmlEncode(Photo));
            adapter.InsertCommand.Parameters.AddWithValue("@Packing", HttpUtility.HtmlEncode(Packing));
            adapter.InsertCommand.Parameters.AddWithValue("@Trash", HttpUtility.HtmlEncode(Trash));
            adapter.InsertCommand.Parameters.AddWithValue("@TDesc", HttpUtility.HtmlEncode(tbTD.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));
            adapter.InsertCommand.ExecuteNonQuery();

            adapter.UpdateCommand = new SqlCommand(query2, sqlConnect);
            adapter.UpdateCommand.Parameters.AddWithValue("@note", HttpUtility.HtmlEncode(txtNoteContents.Text));
            adapter.UpdateCommand.ExecuteNonQuery();

            command.Dispose();
            sqlConnect.Close();
        }




        // Update Btn
        protected void UpdateBtn_Click(object sender, EventArgs e)
        {
            String state = ddlState.SelectedValue;
            String MLS = "No";
            String Photo = "No";
            String Packing = "No";
            String Trash = "No";
            if (cbMLS.Checked)
            {
                MLS = "Yes";
            }
            if (cbPhoto.Checked)
            {
                Photo = "Yes";
            }
            if (cbPacking.Checked)
            {
                Packing = "Yes";
            }
            if (cbTrash.Checked)
            {
                Trash = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "UPDATE MovePreAssessment SET OutDate = @OutDate, EarlyDate = @EarlyDate, LateDate = @LateDate, DestAdd = @DestAdd, DestCity = @DestCity, DestSt = @DestSt, DestZip = @DestZip, MLS = @MLS, Photo = @Photo, Packing = @Packing, Trash = @Trash, TDesc = @TDesc WHERE CustomerID = @id";
            String query2 = "UPDATE Customer SET Note = @note Where CustomerID = " + hiddenCustomerID.Text + "";
            
            SqlCommand command = new SqlCommand(query1, sqlConnect);
            
            sqlConnect.Open();

            adapter.UpdateCommand = new SqlCommand(query1, sqlConnect);
            adapter.UpdateCommand.Parameters.AddWithValue("@OutDate", HttpUtility.HtmlEncode(txtMoveDate.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@EarlyDate", HttpUtility.HtmlEncode(txtEarlyDate.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@LateDate", HttpUtility.HtmlEncode(txtLateDate.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@DestAdd", HttpUtility.HtmlEncode(txtToAdd.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@DestCity", HttpUtility.HtmlEncode(txtToCity.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@DestSt", HttpUtility.HtmlEncode(state));
            adapter.UpdateCommand.Parameters.AddWithValue("@DestZip", HttpUtility.HtmlEncode(txtToZip.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@MLS", HttpUtility.HtmlEncode(MLS));
            adapter.UpdateCommand.Parameters.AddWithValue("@Photo", HttpUtility.HtmlEncode(Photo));
            adapter.UpdateCommand.Parameters.AddWithValue("@Packing", HttpUtility.HtmlEncode(Packing));
            adapter.UpdateCommand.Parameters.AddWithValue("@Trash", HttpUtility.HtmlEncode(Trash));
            adapter.UpdateCommand.Parameters.AddWithValue("@TDesc", HttpUtility.HtmlEncode(tbTD.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));
            adapter.UpdateCommand.ExecuteNonQuery();

            adapter.UpdateCommand = new SqlCommand(query2, sqlConnect);
            adapter.UpdateCommand.Parameters.AddWithValue("@note", HttpUtility.HtmlEncode(txtNoteContents.Text));
            adapter.UpdateCommand.ExecuteNonQuery();


            command.Dispose();
            sqlConnect.Close();
        }

    }
}