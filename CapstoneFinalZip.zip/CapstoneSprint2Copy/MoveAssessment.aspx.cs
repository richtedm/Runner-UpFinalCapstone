﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class MoveAssessment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGridView();
            }

            if (this.Page.PreviousPage != null)
            {
                string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM MoveAssessment INNER JOIN Customer ON MoveAssessment.CustomerID = Customer.CustomerID WHERE MoveAssessment.CustomerID = @id", con);

                SqlCommand cmd2 = new SqlCommand("SELECT Customer.Note FROM Customer WHERE CustomerID = @id", con);

                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                //txtName.Text = Session["CustomerName"].ToString();
                //txtPhone.Text = Session["PhoneNumber"].ToString();
                //txtEmail.Text = Session["Email"].ToString();
                //txtDate.Text = Session["InitialContactDate"].ToString();

                //cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                //cmd2.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                //SqlDataReader dr = cmd.ExecuteReader();

                //while (dr.Read())
                //{
                //    txtMoveDate.Text = dr["OutDate"].ToString();
                //    txtEarlyDate.Text = dr["EarlyDate"].ToString();
                //    txtLateDate.Text = dr["LateDate"].ToString();
                //    txtToAdd.Text = dr["DestAdd"].ToString();
                //    txtToCity.Text = dr["DestCity"].ToString();
                //    ddlState.SelectedItem.Text = dr["DestSt"].ToString();
                //    txtToZip.Text = dr["DestZip"].ToString();
                //    if (dr["MLS"].Equals("Yes"))
                //    {
                //        cbMLS.Checked = true;
                //    }
                //    else
                //    {
                //        cbMLS.Checked = false;
                //    }

                //    if (dr["Photo"].Equals("Yes"))
                //    {
                //        cbPhoto.Checked = true;
                //    }
                //    else
                //    {
                //        cbPhoto.Checked = false;
                //    }

                //    if (dr["Packing"].Equals("Yes"))
                //    {
                //        cbPacking.Checked = true;
                //    }
                //    else
                //    {
                //        cbPacking.Checked = false;
                //    }

                //    if (dr["Trash"].Equals("Yes"))
                //    {
                //        cbTrash.Checked = true;
                //        tbTD.Text = dr["TDesc"].ToString();
                //    }
                //    else
                //    {
                //        cbTrash.Checked = false;
                //    }
                //}

                //dr.Close();
                //SqlDataReader dr2 = cmd2.ExecuteReader();

                //// Data reader from SQL Queries
                //while (dr2.Read())
                //{
                //    txtNoteContents.Text = Server.HtmlDecode(dr2["Note"].ToString());
                //    txtNoteContents.Text = txtNoteContents.Text.Replace("<p>", "");
                //}


                //dr2.Close();
                //con.Close();



            }


        }
        protected void ddlRoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlRoom.SelectedValue.Equals("Bedroom") || ddlRoom.SelectedValue.Equals("Outbuilding"))
            {
                quant.Visible = true;
            }
            else
            {
                quant.Visible = false;
            }
            if (ddlRoom.SelectedValue.Equals("Bedroom"))
            {
                outbuilding.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = true;
                floor.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Outbuilding"))
            {
                attic.Visible = false;
                basement.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = false;
                floor.Visible = false;
                outbuilding.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Attic"))
            {
                outbuilding.Visible = false;
                basement.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = false;
                floor.Visible = false;
                attic.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Basement"))
            {
                outbuilding.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = false;
                floor.Visible = false;
                attic.Visible = false;
                basement.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Library"))
            {
                outbuilding.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                bedroom.Visible = true;
                floor.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Dining Room"))
            {
                outbuilding.Visible = false;
                den.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                bedroom.Visible = false;
                floor.Visible = false;
                dining.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Den"))
            {
                dining.Visible = false;
                outbuilding.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                bedroom.Visible = false;
                den.Visible = true;
                floor.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Living Room"))
            {
                dining.Visible = false;
                outbuilding.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                bedroom.Visible = false;
                floor.Visible = false;
                den.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Laundry Room"))
            {
                outbuilding.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = true;
                floor.Visible = true;
            }
            if (ddlRoom.SelectedValue.Equals("Patio/Deck"))
            {
                outbuilding.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = true;
                floor.Visible = false;
            }
            if (ddlRoom.SelectedValue.Equals("Garage"))
            {
                outbuilding.Visible = false;
                attic.Visible = false;
                basement.Visible = false;
                dining.Visible = false;
                den.Visible = false;
                bedroom.Visible = true;
                floor.Visible = false;
            }
            bool query1 = false;
            //query to check if packing is needed
            if (query1)
            {
                packing.Visible = true;
            }
            else
            {
                packing.Visible = false;
            }
        }
        protected void rblResidence_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rblResidence.SelectedValue.Equals("1"))
            {
                ApartmentChoice.Visible = true;
                StorageChoice.Visible = false;
                BusinessChoice.Visible = false;
            }
            else if (rblResidence.SelectedValue.Equals("3"))
            {
                StorageChoice.Visible = true;
                ApartmentChoice.Visible = false;
                BusinessChoice.Visible = false;
            }
            else if (rblResidence.SelectedValue.Equals("4"))
            {
                BusinessChoice.Visible = true;
                ApartmentChoice.Visible = false;
                StorageChoice.Visible = false;
            }
            else
            {
                BusinessChoice.Visible = false;
                ApartmentChoice.Visible = false;
                StorageChoice.Visible = false;
            }
        }

        protected void cbserver_CheckedChanged(object sender, EventArgs e)
        {
            if (cbserver.Checked == true)
            {
                server.Visible = true;
            }
            else { server.Visible = false; }
        }

        protected void cbchinapress_CheckedChanged(object sender, EventArgs e)
        {
            if (cbchinapress.Checked == true)
            {
                chinapress.Visible = true;
            }
            else { chinapress.Visible = false; }
        }

        protected void cbtable_CheckedChanged(object sender, EventArgs e)
        {
            if (cbtable.Checked == true)
            {
                table.Visible = true;
            }
            else { table.Visible = false; }
        }

        protected void cbsilverchest_CheckedChanged(object sender, EventArgs e)
        {
            if (cbsilverchest.Checked == true)
            {
                silverchest.Visible = true;
            }
            else { silverchest.Visible = false; }
        }

        protected void cbbreakfront_CheckedChanged(object sender, EventArgs e)
        {
            if (cbbreakfront.Checked == true)
            {
                breakfront.Visible = true;
            }
            else { breakfront.Visible = false; }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            String rmname = ddlRoom.SelectedItem.Text;
            String rmdes = "";
            if (ddlRoom.SelectedValue.Equals("Bedroom") || ddlRoom.SelectedValue.Equals("Outbuilding"))
            {
                rmname += txtQuant.Text;
                txtQuant.Text = null;
                if (ddlRoom.SelectedValue.Equals("Bedroom"))
                {
                    String bedroom = "Contents: ";
                    bedroom += txtBedroom.Text + " " + "Floor: " + ddlFloor.SelectedValue.ToString();
                    txtBedroom.Text = null;
                    rmdes = bedroom;
                }
                if (ddlRoom.SelectedValue.Equals("Outbuilding"))
                {
                    String outbuilding = "Contents: ";
                    if (cbpushmower.Checked == true)
                    {
                        outbuilding += "Push Mower, ";
                        cbpushmower.Checked = false;
                    }
                    if (cbridemower.Checked == true)
                    {
                        outbuilding += "Riding Mower, ";
                        cbridemower.Checked = false;
                    }
                    if (cblargetools.Checked == true)
                    {
                        outbuilding += "Large Tools, ";
                        cblargetools.Checked = false;
                    }
                    outbuilding += txtoutbuilding.Text;
                    txtoutbuilding.Text = null;
                    rmdes = outbuilding;
                }
            }
            if (ddlRoom.SelectedValue.Equals("Attic"))
            {
                String attic = "Accessibility: ";
                if (cbstairs.Checked == true)
                {
                    attic += "Pull Down Steps ";
                    cbstairs.Checked = false;
                }
                attic += txtaccess.Text + " Contents: " + txtattic.Text;
                txtaccess.Text = null;
                txtattic.Text = null;
                rmdes = attic;
            }
            if (ddlRoom.SelectedValue.Equals("Basement"))
            {
                String basement = "Accessibility: ";
                if (cboutside.Checked == true)
                {
                    basement += "Outside Entrance, ";
                    cboutside.Checked = false;
                }
                else { basement += "No Outside Entrance, "; }
                if (cbtruck.Checked == true)
                {
                    basement += "Truck can get to door ";
                    cbtruck.Checked = false;
                }
                else { basement += "Truck cannot get to door "; }
                basement += "Contents: " + txtbasement.Text;
                txtbasement.Text = null;
                rmdes = basement;
            }
            if (ddlRoom.SelectedValue.Equals("Library"))
            {
                String library = "Contents: ";
                library += txtBedroom.Text + " " + "Floor: " + ddlFloor.SelectedValue.ToString();
                txtBedroom.Text = null;
                rmdes = library;
            }
            if (ddlRoom.SelectedValue.Equals("Dining Room"))
            {
                String dining = "Contents: ";
                if (cbserver.Checked == true)
                {
                    dining += "Server(";
                    if (cbsideboard.Checked == true)
                    {
                        dining += "Sideboard, ";
                        cbsideboard.Checked = false;
                    }
                    if (cbmirrorback.Checked == true)
                    {
                        dining += "Mirror Back, ";
                        cbmirrorback.Checked = false;
                    }
                    if (cbmarbletop.Checked == true)
                    {
                        dining += "Marble Top,";
                        cbmarbletop.Checked = false;
                    }
                    if (cbserverval.Checked == true)
                    {
                        dining += "High Value), ";
                        cbserverval.Checked = false;
                    }
                    else { dining += "Lower Value), "; }
                    cbserver.Checked = false;
                }
                if (cbchinapress.Checked == true)
                {
                    dining += "China Press(";
                    if (cbbowfront.Checked == true)
                    {
                        dining += "Bowfront, ";
                        cbbowfront.Checked = false;
                    }
                    if (cb2piece.Checked == true)
                    {
                        dining += "Two-Piece, ";
                        cb2piece.Checked = false;
                    }
                    if (cbchinaval.Checked == true)
                    {
                        dining += "High Value), ";
                        cbchinaval.Checked = false;
                    }
                    else { dining += "Lower Value), "; }
                    cbchinapress.Checked = false;
                }
                if (cbtable.Checked == true)
                {
                    dining += "Table(" + txtleaves.Text + " Leaves, " + txtchairs.Text + " Chairs, ";
                    txtleaves.Text = null;
                    txtchairs.Text = null;
                    if (cbtableval.Checked == true)
                    {
                        dining += "High Value), ";
                        cbtableval.Checked = false;
                    }
                    else { dining += "Lower Value), "; }
                    cbtable.Checked = false;
                }
                if (cbpedestal.Checked == true)
                {
                    dining += "Pedestal Table/Plant Stand, ";
                    cbpedestal.Checked = false;
                }
                if (cbsilverchest.Checked == true)
                {
                    dining += "Silver Chest(";
                    if (cbsilverval.Checked == true)
                    {
                        dining += "High Value), ";
                        cbsilverval.Checked = false;
                    }
                    else { dining += "Lower Value), "; }
                    cbsilverchest.Checked = false;
                }
                if (cbrug.Checked == true)
                {
                    dining += "Rug, ";
                    cbrug.Checked = false;
                }
                if (cbbreakfront.Checked == true)
                {
                    dining += "Breakfront(";
                    if (cb2fpiece.Checked == true)
                    {
                        dining += "Two-Piece, ";
                        cb2fpiece.Checked = false;
                    }
                    if (cbbreakfrontval.Checked == true)
                    {
                        dining += "High Value), ";
                        cbbreakfrontval.Checked = false;
                    }
                    else { dining += "Lower Value), "; }
                    cbbreakfront.Checked = false;
                }
                dining += txtdining.Text;
                txtdining.Text = null;
                rmdes = dining;
            }
            if (ddlRoom.SelectedValue.Equals("Den"))
            {
                String den = "Contents: ";
                if (cbleather.Checked == true)
                {
                    den += txtsofas.Text + " Leather Sofas, ";
                    txtsofas.Text = null;
                    cbleather.Checked = false;
                }
                else { den += txtsofas.Text + " Sofas"; }
                den += txtden.Text + " Floor: " + ddlFloor.SelectedValue.ToString();
                txtden.Text = null;
                rmdes = den;
            }
            if (ddlRoom.SelectedValue.Equals("Living Room"))
            {
                String livingroom = "Contents: ";
                if (cbleather.Checked == true)
                {
                    livingroom += txtsofas.Text + " Leather Sofas, ";
                    cbleather.Checked = false;
                }
                else { livingroom += txtsofas.Text + " Sofas"; }
                txtsofas.Text = null;
                rmdes = livingroom;
            }
            if (ddlRoom.SelectedValue.Equals("Laundry Room"))
            {
                String laundry = "Contents: ";
                laundry += txtBedroom.Text + " " + "Floor: " + ddlFloor.SelectedValue.ToString();
                txtBedroom.Text = null;
                rmdes = laundry;
            }
            if (ddlRoom.SelectedValue.Equals("Patio/Deck"))
            {
                String patio = "Contents: ";
                patio += txtBedroom.Text;
                txtBedroom.Text = null;
                rmdes = patio;
            }
            if (ddlRoom.SelectedValue.Equals("Garage"))
            {
                String garage = "Contents: ";
                garage += txtBedroom.Text;
                txtBedroom.Text = null;
                rmdes = garage;
            }
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("select * from AuctionInv"))
                {
                    cmd.Connection = sqlConnect;
                    sqlConnect.Open();

                    cmd.CommandText = "INSERT INTO MoveInv (RmName, RmDes, SmBox, MdBox, LgBox, WdBox, ArtBox, CubicFt, CustomerID) " + "VALUES(@RmName, @RmDes, @SmBox, @MdBox, @LgBox, @WdBox, @ArtBox, @CubicFt, @id)";
                    cmd.Parameters.AddWithValue("@RmName", rmname);
                    cmd.Parameters.AddWithValue("@RmDes", rmdes);
                    cmd.Parameters.AddWithValue("@SmBox", txtSmall.Text);
                    cmd.Parameters.AddWithValue("@MdBox", txtMed.Text);
                    cmd.Parameters.AddWithValue("@LgBox", txtLarge.Text);
                    cmd.Parameters.AddWithValue("@Wdbox", txtWardrobe.Text);
                    cmd.Parameters.AddWithValue("@ArtBox", txtArt.Text);
                    cmd.Parameters.AddWithValue("@CubicFt", txtcb.Text);
                    cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                    cmd.ExecuteNonQuery();
                }
            }
            BindGridView();
            room.Visible = false;
            btnAdd.Visible = false;
        }
        private void BindGridView()
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {


                
                using (SqlCommand cmd = new SqlCommand("SELECT RmName, RmDes FROM MoveInv INNER JOIN Customer ON MoveInv.CustomerID = Customer.CustomerID  WHERE MoveInv.CustomerID = @id"))
                
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                        cmd.Connection = sqlConnect;
                        sda.SelectCommand = cmd;
                        
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridViewRoom.DataSource = dt;
                            GridViewRoom.DataBind();
                        }
                    }
                }
            }
        }

        protected void GridViewRoom_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow row = (GridViewRow)GridViewRoom.Rows[e.RowIndex];
            String name = row.Cells[1].Text;
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("delete from MoveInv where RmName='" + name + "'"))//doesnt work
                {
                    cmd.Connection = sqlConnect;
                    sqlConnect.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnect.Close();
                }
            }
            this.BindGridView();
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            room.Visible = true;
            btnAdd.Visible = true;
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            String homeDetail = rblResidence.SelectedItem.Text;
            if (homeDetail.Equals("Apartment"))
            {
                homeDetail += " Floor: " + txtFloor.Text + " Elevator: " + txtElevator.Text + " Distance: " + txtStep.Text;
            }
            else if (homeDetail.Equals("Storage Unit"))
            {
                if (cbAC.Checked == true)
                {
                    homeDetail += " Climate Controlled";
                }
                else
                {
                    homeDetail += " Not Climate Controlled";
                }
            }
            else if (homeDetail.Equals("Place of Business"))
            {
                homeDetail += " Business Name: " + txtBusiness.Text;
            }
            String appCart = "No";
            String pianoDolly = "No";
            String pianoBoard = "No";
            String gunSafe = "No";
            String extraBlanket = "No";
            if (cbAppliance.Checked == true)
            {
                appCart = "Yes";
            }
            if (cbPDolly.Checked == true)
            {
                pianoDolly = "Yes";
            }
            if (cbPBoard.Checked == true)
            {
                pianoBoard = "Yes";
            }
            if (cbGun.Checked == true)
            {
                gunSafe = "Yes";
            }
            if (cbBlankets.Checked == true)
            {
                extraBlanket = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "Insert into MoveAssessment(Residence, TruckAccess, WalkToDoor, StepsToHouse, NeedApplianceCart, NeedPianoDolly, NeedPianoBoard, NeedGunCart, NeedExtraBlankets, Trucks, PickupFee, ConsignmentFee, TrashFee, AdditionalFee, CustomerID) VALUES(@Residence, @TruckAccess, @WalkToDoor, @StepsToHouse, @NeedApplianceCart, @NeedPianoDolly, @NeedPianoBoard, @NeedGunCart, @NeedExtraBlankets, @Trucks, @PickupFee, @ConsignmentFee, @TrashFee, @AdditionalFee, @id)";
            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@Residence", HttpUtility.HtmlEncode(homeDetail));
            adapter.InsertCommand.Parameters.AddWithValue("@TruckAccess", HttpUtility.HtmlEncode(txtTAccess.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@WalkToDoor", HttpUtility.HtmlEncode(txtFar.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@StepsToHouse", HttpUtility.HtmlEncode(txtStep.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedApplianceCart", HttpUtility.HtmlEncode(appCart));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedPianoDolly", HttpUtility.HtmlEncode(pianoDolly));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedPianoBoard", HttpUtility.HtmlEncode(pianoBoard));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedGunCart", HttpUtility.HtmlEncode(gunSafe));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedExtraBlankets", HttpUtility.HtmlEncode(extraBlanket));
            adapter.InsertCommand.Parameters.AddWithValue("@Trucks", HttpUtility.HtmlEncode(txtTrucks.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@PickupFee", HttpUtility.HtmlEncode(txtPickup.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@ConsignmentFee", HttpUtility.HtmlEncode(txtConsignment.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@TrashFee", HttpUtility.HtmlEncode(txtTrash.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@AdditionalFee", HttpUtility.HtmlEncode(txtAdditional.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            sqlConnect.Close();
        }
    }
}