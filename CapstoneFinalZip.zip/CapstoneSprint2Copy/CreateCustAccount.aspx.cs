﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class CreateCustAccount : System.Web.UI.Page
    {
        
            protected void Page_Load(object sender, EventArgs e)
            {

            }

            protected void btnCreate_Click(object sender, EventArgs e)
            {
                // Define connection to the database:
                SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["AUTH"].ConnectionString);
                sqlConnect.Open();

                String sqlInsert = "INSERT INTO Person (FirstName, LastName, Username, Address, PhoneNumber) VALUES (@cFN, @cLN, @username, @cAddress, @cPN)";

                SqlCommand sqlCmd = new SqlCommand(sqlInsert, sqlConnect);
                sqlCmd.Parameters.Add(new SqlParameter("@cFN", txtCustFN.Text));
                sqlCmd.Parameters.Add(new SqlParameter("@cLN", txtCustLN.Text));
                sqlCmd.Parameters.Add(new SqlParameter("@username", txtUsername.Text));
                sqlCmd.Parameters.Add(new SqlParameter("@cAddress", txtCustAddress.Text));
                sqlCmd.Parameters.Add(new SqlParameter("@cPN", txtPhoneNumber.Text));
                sqlCmd.ExecuteNonQuery();





                String sqlInsertTwo = "INSERT INTO Pass (UserID, Username, PasswordHash) VALUES ((select max(userid) from person), @username, @password)";




                SqlCommand sqlCmdTwo = new SqlCommand(sqlInsertTwo, sqlConnect);
                sqlCmdTwo.Parameters.Add(new SqlParameter("@username", txtUsername.Text));
                sqlCmdTwo.Parameters.Add(new SqlParameter("@password", PasswordHash.HashPassword(txtPassword.Text)));
                sqlCmdTwo.ExecuteNonQuery();



                //sqlConnect.Open();
                // sqlCmd.ExecuteNonQuery();
                // sqlCmdTwo.ExecuteNonQuery();
                sqlConnect.Close();
            }

            protected void btnCustLogin_Click(object sender, EventArgs e)
            {
                // redirect to Employee Login page
                Response.Redirect("CustomerLogin.aspx");
            }

            protected void btnBack_Click(object sender, EventArgs e)
            {
                // redirect to Intro page
                Response.Redirect("Home.aspx");
            }

            protected void btnPopulate_Click(object sender, EventArgs e)
            {
                txtUsername.Text = "Eren@gmail.com" + HttpUtility.HtmlEncode(txtUsername.Text);
                txtCustFN.Text = "Eren" + HttpUtility.HtmlEncode(txtCustFN.Text);
                txtCustLN.Text = "Jager" + HttpUtility.HtmlEncode(txtCustLN.Text);
                txtCustAddress.Text = "223 Home Dr" + HttpUtility.HtmlEncode(txtCustAddress.Text);
                txtPhoneNumber.Text = "123-123-1234" + HttpUtility.HtmlEncode(txtPhoneNumber.Text);
                txtPassword.Text = "test" + HttpUtility.HtmlEncode(txtPassword.Text);
            }

            protected void btnClear_Click(object sender, EventArgs e)
            {
                txtUsername.Text = "";
                txtCustFN.Text = "";
                txtCustLN.Text = "";
                txtCustAddress.Text = "";
                txtPhoneNumber.Text = "";
                txtPassword.Text = "";
            }
        }
}