﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class AuctionAssessment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGridView();
            }
        }
        protected void btInsert_Click(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            GridViewRow row = (GridViewRow)bt.Parent.Parent;

            TextBox tbItemName = (TextBox)row.Cells[0].FindControl("tbItemName");
            TextBox tbItemDescription = (TextBox)row.Cells[0].FindControl("tbItemDescription");

            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("select * from AuctionInv"))
                {
                    cmd.Connection = sqlConnect;
                    sqlConnect.Open();

                    cmd.CommandText = "INSERT INTO AuctionInv (ItemName, ItemDescription) " + "VALUES(@ItemName, @ItemDescription)";
                    cmd.Parameters.AddWithValue("@ItemName", tbItemName.Text.Trim());
                    cmd.Parameters.AddWithValue("@ItemDescription", tbItemDescription.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
            }
            BindGridView();
        }
        protected void GridViewRoomName_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow row = (GridViewRow)GridViewItemName.Rows[e.RowIndex];
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("delete from AuctionInv where ItemID='" + Convert.ToInt32(GridViewItemName.DataKeys[e.RowIndex].Value.ToString()) + "'"))
                {
                    cmd.Connection = sqlConnect;
                    sqlConnect.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnect.Close();
                }
            }
            this.BindGridView();
        }
        private void BindGridView()
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("select *" +
                    "FROM AuctionInv"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = sqlConnect;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridViewItemName.DataSource = dt;
                            GridViewItemName.DataBind();
                        }
                    }
                }
            }
        }
        protected void rblResidence_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rblResidence.SelectedValue.Equals("1"))
            {
                ApartmentChoice.Visible = true;
                StorageChoice.Visible = false;
                BusinessChoice.Visible = false;
            }
            else if (rblResidence.SelectedValue.Equals("3"))
            {
                StorageChoice.Visible = true;
                ApartmentChoice.Visible = false;
                BusinessChoice.Visible = false;
            }
            else if (rblResidence.SelectedValue.Equals("4"))
            {
                BusinessChoice.Visible = true;
                ApartmentChoice.Visible = false;
                StorageChoice.Visible = false;
            }
            else
            {
                BusinessChoice.Visible = false;
                ApartmentChoice.Visible = false;
                StorageChoice.Visible = false;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            String homeDetail = rblResidence.SelectedItem.Text;
            if (homeDetail.Equals("Apartment"))
            {
                homeDetail += " Floor: " + txtFloor.Text + " Elevator: " + txtElevator.Text + " Distance: " + txtStep.Text;
            }
            else if (homeDetail.Equals("Storage Unit"))
            {
                if (cbAC.Checked == true)
                {
                    homeDetail += " Climate Controlled";
                }
                else
                {
                    homeDetail += " Not Climate Controlled";
                }
            }
            else if (homeDetail.Equals("Place of Business"))
            {
                homeDetail += " Business Name: " + txtBusiness.Text;
            }
            String appCart = "No";
            String pianoDolly = "No";
            String pianoBoard = "No";
            String gunSafe = "No";
            String extraBlanket = "No";
            if (cbAppliance.Checked == true)
            {
                appCart = "Yes";
            }
            if (cbPDolly.Checked == true)
            {
                pianoDolly = "Yes";
            }
            if (cbPBoard.Checked == true)
            {
                pianoBoard = "Yes";
            }
            if (cbGun.Checked == true)
            {
                gunSafe = "Yes";
            }
            if (cbBlankets.Checked == true)
            {
                extraBlanket = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "Insert into AuctionAssessment(Residence, TruckAccess, WalkToDoor, StepsToHouse, NeedApplianceCart, NeedPianoDolly, NeedPianoBoard, NeedGunCart, NeedExtraBlankets, Trucks, SmBox, MdBox, LgBox, Art, SmPads, LgPads, PickupFee, ConsignmentFee, TrashFee, AdditionalFee) VALUES(@Residence, @TruckAccess, @WalkToDoor, @StepsToHouse, @NeedApplianceCart, @NeedPianoDolly, @NeedPianoBoard, @NeedGunCart, @NeedExtraBlankets, @Trucks, @SmBox, @MdBox, @LgBox, @Art, @SmPads, @LgPads, @PickupFee, @ConsignmentFee, @TrashFee, @AdditionalFee)";
            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@Residence", HttpUtility.HtmlEncode(homeDetail));
            adapter.InsertCommand.Parameters.AddWithValue("@TruckAccess", HttpUtility.HtmlEncode(txtAccess.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@WalkToDoor", HttpUtility.HtmlEncode(txtFar.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@StepsToHouse", HttpUtility.HtmlEncode(txtStep.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedApplianceCart", HttpUtility.HtmlEncode(appCart));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedPianoDolly", HttpUtility.HtmlEncode(pianoDolly));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedPianoBoard", HttpUtility.HtmlEncode(pianoBoard));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedGunCart", HttpUtility.HtmlEncode(gunSafe));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedExtraBlankets", HttpUtility.HtmlEncode(extraBlanket));
            adapter.InsertCommand.Parameters.AddWithValue("@Trucks", HttpUtility.HtmlEncode(txtTrucks.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@SmBox", HttpUtility.HtmlEncode(txtSmall.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@MdBox", HttpUtility.HtmlEncode(txtMed.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@LgBox", HttpUtility.HtmlEncode(txtLarge.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Art", HttpUtility.HtmlEncode(txtArt.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@SmPads", HttpUtility.HtmlEncode(txtSPad.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@LgPads", HttpUtility.HtmlEncode(txtLPad.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@PickupFee", HttpUtility.HtmlEncode(txtPickup.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@ConsignmentFee", HttpUtility.HtmlEncode(txtConsignment.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@TrashFee", HttpUtility.HtmlEncode(txtTrash.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@AdditionalFee", HttpUtility.HtmlEncode(txtAdditional.Text));
      //      adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));

            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            sqlConnect.Close();
        }

        // Idk if this does what we need it to or if we will just send the person all the way back home
        protected void btnBack_Click(object sender, EventArgs e) 
        {
            Response.Redirect("Home.aspx");
        }
    }
}