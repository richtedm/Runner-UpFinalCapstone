﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class AuctionPreAssessment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            hiddenID.Text = Session["CustomerID"].ToString();
            txtName.Text = Session["CustomerName"].ToString();
            txtEmail.Text = Session["Email"].ToString();
            txtPhone.Text = Session["PhoneNumber"].ToString();
            txtAddress.Text = Session["Address"].ToString();


            existingFormDatasrc.SelectParameters.Add("CustomerID", hiddenID.Text);
        }

        protected void btnNote_Click(object sender, EventArgs e) 
        {
            txtNoteContents.Visible = true;
            saveNoteChangesBtn.Visible = true;

            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);

            SqlCommand command = new SqlCommand("SELECT Note FROM Customer Where CustomerID = @id", sqlConnect);

            sqlConnect.Open();

            adapter.SelectCommand = command;

            adapter.SelectCommand.Parameters.AddWithValue("@id", hiddenID.Text);
            adapter.SelectCommand.ExecuteNonQuery();


            //Data reader lines
            SqlDataReader rdr = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            rdr.Read();

            txtNoteContents.Text = rdr["Note"].ToString();
        }

        protected void SelectFormBtn_Click(object sender, EventArgs e) 
        {
            // Fills Textboxes with Data from AuctionPreAssessment Where Date= DateDropdown

            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            // MoveDate will change when we decide what kind of data to sort via on this form. 
            SqlCommand command = new SqlCommand("SELECT * FROM AuctionPreAssessment Where MoveDate = @date", sqlConnect);



            sqlConnect.Open();

            adapter.SelectCommand = command;

            adapter.SelectCommand.Parameters.AddWithValue("@date", existingFormDDL.SelectedItem.Text);
            adapter.SelectCommand.ExecuteNonQuery();

            SqlDataReader rdr = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            rdr.Read();

            txtSell.Text = rdr["sell"].ToString();
            ddlWhy.SelectedValue = rdr["Why"].ToString();
            txtMoveDate.Text = rdr["Deadline"].ToString();
            



            SubmitFormBtn.Visible = false;
            UpdateFormBtn.Visible = true;
        }

        protected void saveNoteChanges_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);

            SqlCommand command = new SqlCommand("UPDATE Customer SET Note = @note WHERE CustomerID = " + hiddenID.Text + "", sqlConnect);

            sqlConnect.Open();

            //Parameterized Queries
            adapter.UpdateCommand = command;
            adapter.UpdateCommand.Parameters.AddWithValue("@note", HttpUtility.HtmlEncode(txtNoteContents.Text));
            adapter.UpdateCommand.ExecuteNonQuery();

            // Close Connection
            command.Dispose();
            sqlConnect.Close();
        }

        protected void cbWalk_CheckedChanged(object sender, EventArgs e)
        {
            if (cbWalk.Checked)
            {
                ddlWalk.Visible = true;
            }
            else
            {
                ddlWalk.Visible = false;
            }
        }

        protected void cbTrash_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTrash.Checked == true)
            {
                tbTD.Visible = true;
            }
            else { tbTD.Visible = false; }
        }

        protected void UpdateFormBtn_Click(object sender, EventArgs e) 
        {
            String why = ddlWhy.SelectedIndex.ToString();
            String photo = "No";
            String item = "No";
            String bring = "No";
            String walk = "No";
            String walkInfo = ddlWalk.SelectedIndex.ToString();
            String pickup = "No";
            String trash = "No";
            String move = "No";
            String appraisal = "No";
            if (cbPhoto.Checked)
            {
                photo = "Yes";
            }
            if (cbItems.Checked)
            {
                item = "Yes";
            }
            if (cbBring.Checked)
            {
                bring = "Yes";
            }
            if (cbWalk.Checked)
            {
                walk = "Yes";
            }
            if (cbPickup.Checked)
            {
                pickup = "Yes";
            }
            if (cbTrash.Checked)
            {
                trash = "Yes";
            }
            if (cbMove.Checked)
            {
                move = "Yes";
            }
            if (cbAppraisal.Checked)
            {
                appraisal = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            //String query1 = "Insert into AuctionPreAssessment(Sell, Why, MoveDate, Photo, Items, Bring, Walk, WalkInfo, Pickup, Trash, TrashDesc, Moving, Appraisal, CustomerID) VALUES(@Sell, @Why, @MoveDate, @Photo, @Items, @Bring, @Walk, @WalkInfo, @Pickup, @Trash, @TrashDesc, @Moving, @Appraisal, @id)";

            String query1 = "Insert into AuctionPreAssessment(Sell, Why, MoveDate, Photo, Items, Bring, Walk, WalkInfo, Pickup, Trash, TrashDesc, Moving, Appraisal, CustomerID) VALUES(@Sell, @Why, @MoveDate, @Photo, @Items, @Bring, @Walk, @WalkInfo, @Pickup, @Trash, @TrashDesc, @Moving, @Appraisal, @id)";


            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@Sell", HttpUtility.HtmlEncode(txtSell.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Why", HttpUtility.HtmlEncode(why));
            adapter.InsertCommand.Parameters.AddWithValue("@MoveDate", HttpUtility.HtmlEncode(txtMoveDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Photo", HttpUtility.HtmlEncode(photo));
            adapter.InsertCommand.Parameters.AddWithValue("@Items", HttpUtility.HtmlEncode(item));
            adapter.InsertCommand.Parameters.AddWithValue("@Bring", HttpUtility.HtmlEncode(bring));
            adapter.InsertCommand.Parameters.AddWithValue("@Walk", HttpUtility.HtmlEncode(walk));
            adapter.InsertCommand.Parameters.AddWithValue("@WalkInfo", HttpUtility.HtmlEncode(walkInfo));
            adapter.InsertCommand.Parameters.AddWithValue("@Pickup", HttpUtility.HtmlEncode(pickup));
            adapter.InsertCommand.Parameters.AddWithValue("@Trash", HttpUtility.HtmlEncode(trash));
            adapter.InsertCommand.Parameters.AddWithValue("@TrashDesc", HttpUtility.HtmlEncode(tbTD.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Moving", HttpUtility.HtmlEncode(move));
            adapter.InsertCommand.Parameters.AddWithValue("@Appraisal", HttpUtility.HtmlEncode(appraisal));
            adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenID.Text));
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            sqlConnect.Close();
        }


        protected void SubmitFormBtn_Click(object sender, EventArgs e)
        {
            String why = ddlWhy.SelectedIndex.ToString();
            String photo = "No";
            String item = "No";
            String bring = "No";
            String walk = "No";
            String walkInfo = ddlWalk.SelectedIndex.ToString();
            String pickup = "No";
            String trash = "No";
            String move = "No";
            String appraisal = "No";
            if (cbPhoto.Checked)
            {
                photo = "Yes";
            }
            if (cbItems.Checked)
            {
                item = "Yes";
            }
            if (cbBring.Checked)
            {
                bring = "Yes";
            }
            if (cbWalk.Checked)
            {
                walk = "Yes";
            }
            if (cbPickup.Checked)
            {
                pickup = "Yes";
            }
            if (cbTrash.Checked)
            {
                trash = "Yes";
            }
            if (cbMove.Checked)
            {
                move = "Yes";
            }
            if (cbAppraisal.Checked)
            {
                appraisal = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "Insert into AuctionPreAssessment(Sell, Why, MoveDate, Photo, Items, Bring, Walk, WalkInfo, Pickup, Trash, TrashDesc, Moving, Appraisal, CustomerID) VALUES(@Sell, @Why, @MoveDate, @Photo, @Items, @Bring, @Walk, @WalkInfo, @Pickup, @Trash, @TrashDesc, @Moving, @Appraisal, @id)";
            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@Sell", HttpUtility.HtmlEncode(txtSell.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Why", HttpUtility.HtmlEncode(why));
            adapter.InsertCommand.Parameters.AddWithValue("@MoveDate", HttpUtility.HtmlEncode(txtMoveDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Photo", HttpUtility.HtmlEncode(photo));
            adapter.InsertCommand.Parameters.AddWithValue("@Items", HttpUtility.HtmlEncode(item));
            adapter.InsertCommand.Parameters.AddWithValue("@Bring", HttpUtility.HtmlEncode(bring));
            adapter.InsertCommand.Parameters.AddWithValue("@Walk", HttpUtility.HtmlEncode(walk));
            adapter.InsertCommand.Parameters.AddWithValue("@WalkInfo", HttpUtility.HtmlEncode(walkInfo));
            adapter.InsertCommand.Parameters.AddWithValue("@Pickup", HttpUtility.HtmlEncode(pickup));
            adapter.InsertCommand.Parameters.AddWithValue("@Trash", HttpUtility.HtmlEncode(trash));
            adapter.InsertCommand.Parameters.AddWithValue("@TrashDesc", HttpUtility.HtmlEncode(tbTD.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Moving", HttpUtility.HtmlEncode(move));
            adapter.InsertCommand.Parameters.AddWithValue("@Appraisal", HttpUtility.HtmlEncode(appraisal));
            adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenID.Text));
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            sqlConnect.Close();

        }
    }
}