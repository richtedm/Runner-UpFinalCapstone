﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class PointOfContactForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DateTime d = new DateTime();
            d = DateTime.Now;
            
            txtDateOfContact.Text = d.ToString("MMMM dd, yyyy", System.Globalization.CultureInfo.InvariantCulture);
        }


        protected void btnDate_Click(object sender, EventArgs e) 
        {
            //txtDeadline.Text = Calendar1.SelectedDate.ToShortDateString();
        }



        

        // Populate Button for Demonstration Purposes
        protected void populateBtn_Click(object sender, EventArgs e)
        {
   //         txtCustomerFN.Text = "Kanye" + HttpUtility.HtmlEncode(txtCustomerFN.Text);
   //         txtCustomerLN.Text = "West" + HttpUtility.HtmlEncode(txtCustomerLN.Text);
   //         ddlTypeOfContact.SelectedValue = "2";
   //         txtPhoneNumber.Text = "555-555-5555" + HttpUtility.HtmlEncode(txtPhoneNumber.Text);
   //         txtEmail.Text = "KanyeWest@gmail.com" + HttpUtility.HtmlEncode(txtEmail.Text);
   //         txtCurrentAddress.Text = "123 Famous Rd" + HttpUtility.HtmlEncode(txtCurrentAddress.Text);
   ////         cblServiceNeeded.SelectedValue = "1";
   // //        cblAuctionNeeds.SelectedValue = "1";
   // //        txtAuctionAddress.Text = "45 Sweet Rd" + HttpUtility.HtmlEncode(txtAuctionAddress.Text);
   //         //txtDateOfContact.Text = "06/2/2021" + HttpUtility.HtmlEncode(txtDateOfContact.Text);
   ////         txtDeadline.Text = "11/14/2021" + HttpUtility.HtmlEncode(txtDeadline.Text);
   //         txtCustomerHeard.Text = "Online Ad" + HttpUtility.HtmlEncode(txtCustomerHeard.Text);
   //         txtNoteContents.Text = "Very famous artist" + HttpUtility.HtmlEncode(txtNoteContents.Text);
        }


        // button for going back to the home page 
        protected void btnBackHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        // button for Navigating to Service Order Form 
        protected void btnServiceOrderForm_Click(object sender, EventArgs e)
        {
            //Response.Redirect("ServiceOrderForm1.aspx");
        }





        // button for submitting customer information to Customer Table
        protected void btnSubmitCustomer_Click(object sender, EventArgs e)
        {

            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);

            // Query to insert to Customer Table
            String query1 = "INSERT into Customer(CustomerName, Phonenumber, Email, CurrentAddress, InitialContactDate, ContactMethod, DiscoveryInquiry, Note) VALUES(@Name, @Phonenumber, @Email, @Address, @InitialContact, @ContactMethod, @DiscInq, @Note)";

            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            //Parameterized Queries For Customer Table 
            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@Name", HttpUtility.HtmlEncode(txtCustomerFN.Text + " " + txtCustomerLN.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Phonenumber", HttpUtility.HtmlEncode(txtPhoneNumber.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Email", HttpUtility.HtmlEncode(txtEmail.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Address", HttpUtility.HtmlEncode(txtCurrentAddress.Text + ", " + txtCity.Text + ", " + ddlState.SelectedValue + " " + txtZipcode.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@InitialContact", HttpUtility.HtmlEncode(txtDateOfContact.Text));
            // Was selectedValue
            adapter.InsertCommand.Parameters.AddWithValue("@ContactMethod", HttpUtility.HtmlEncode(customerContactDDL.SelectedItem.ToString()));
            adapter.InsertCommand.Parameters.AddWithValue("@DiscInq", HttpUtility.HtmlEncode(CustomerHeardDDL.SelectedItem.ToString()));
            adapter.InsertCommand.Parameters.AddWithValue("@Note", HttpUtility.HtmlEncode(txtNoteContents.Text));
            adapter.InsertCommand.ExecuteNonQuery();

            // Close Connection
            command.Dispose();
            sqlConnect.Close();

        }

        protected void btnPopulate_Click(object sender, EventArgs e)
        {
            txtCustomerFN.Text = "Steve" + HttpUtility.HtmlEncode(txtCustomerFN.Text);
            txtCustomerLN.Text = "Smith" + HttpUtility.HtmlEncode(txtCustomerLN.Text);
            txtPhoneNumber.Text = "555-555-5555" + HttpUtility.HtmlEncode(txtPhoneNumber.Text);
            txtEmail.Text = "SteveSmith@gmail.com" + HttpUtility.HtmlEncode(txtEmail.Text);
            txtCurrentAddress.Text = "123 Real Rd" + HttpUtility.HtmlEncode(txtCurrentAddress.Text);
            txtCity.Text = "Suffolk" + HttpUtility.HtmlEncode(txtCity.Text);
            ddlState.SelectedValue = "Alabama";
            txtZipcode.Text = "23434" + HttpUtility.HtmlEncode(txtZipcode.Text);
            customerContactDDL.SelectedValue = "Phone";
            CustomerHeardDDL.SelectedValue = "Word of Mouth";
            txtNoteContents.Text = "Very generic man" + HttpUtility.HtmlEncode(txtNoteContents.Text);

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtCustomerFN.Text = "";
            txtCustomerLN.Text = "";
            txtPhoneNumber.Text = "";
            txtEmail.Text = "";
            txtCurrentAddress.Text = "";
            txtCity.Text = "";
            ddlState.SelectedValue = "";
            txtZipcode.Text = "";
            customerContactDDL.SelectedValue = "Choose...";
            CustomerHeardDDL.SelectedValue = "Choose...";
            txtNoteContents.Text = "";
        }
    }
}