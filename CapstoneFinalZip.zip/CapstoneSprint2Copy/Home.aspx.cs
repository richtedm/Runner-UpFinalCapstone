﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {


            }
            else
            {
                Session["InvalidUse"] = "You must first login to access the home page!";
                Response.Redirect("Login.aspx");

            }

            if (!this.IsPostBack)
            {
                this.BindGridView();
            }


        }
        protected void LogoutBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }


        

        protected void ReportBtn_Click(object sender, EventArgs e) 
        {
            Response.Redirect("Reports.aspx");
        }

        // Search Bar + Button... Search by name, email, phone#, or address
        protected void searchBtn_Click(object sender, EventArgs e)
        {
            String query1 = "Select CustomerID, CustomerName, Email, PhoneNumber, CurrentAddress, InitialContactDate FROM Customer Where ([CustomerName] like ('%" + searchText.Text + "%') or [PhoneNumber] like ('%" + searchText.Text + "%') or[Email] like ('%" + searchText.Text + "%') or[CurrentAddress] like ('%" + searchText.Text + "%'))";

            //         server = capstonedb.cvddewsgfcwg.us - east - 1.rds.amazonaws.com; database = Capstone; uid = MasterAdmin; password = LOT2307D;
            //        SqlConnection sqlConnect = new SqlConnection("server = capstonedb.cvddewsgfcwg.us - east - 1.rds.amazonaws.com; database = Capstone;");
            //this is the starter one        SqlConnection sqlConnect = new SqlConnection("Server=Localhost;Database=Capstone;Trusted_Connection=Yes;");


            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString.ToString());



            SqlDataAdapter sqlAdapter = new SqlDataAdapter(query1, sqlConnect);

            DataTable dtForGridView = new DataTable();
            sqlAdapter.Fill(dtForGridView);

            resultsGrid.DataSource = dtForGridView;
            resultsGrid.DataBind();
        }


        // Row command for customer search table
        protected void ResultsGrid_RowCommand(object sender, CommandEventArgs e)
        {
            if (e.CommandName == "View") 
            {
                // Saves selected Row as index 'row'    then can use row.Cells[whatever column you want to select] to bind to whatever                
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = resultsGrid.Rows[index];

                // Binding Gridview Column fields to session variables 
                Session["CustomerID"] = row.Cells[0].Text;
                Session["CustomerName"] = row.Cells[1].Text;
                Session["Email"] = row.Cells[2].Text;
                Session["PhoneNumber"] = row.Cells[3].Text;
                Session["Address"] = row.Cells[4].Text;
                Session["InitialContactDate"] = row.Cells[5].Text;

                // server.transfer like response.redirect but saves info moving over to other page i think...
                Server.Transfer("CustomerLandingPage.aspx");

            }

            //    else
            //    {
            //        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please select a row with valid data')", true);
            //    }



            //String CustomerID = e.CommandArgument.ToString();



            //Response.Redirect("CustomerLandingPage.aspx");


        }


        // Bind GridView for Notification Table
        private void BindGridView()
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("select JobTicketID, JobTicket.CustomerID, CustomerName, Email, Phonenumber, CurrentAddress, InitialContactDate, TicketTitle, TicketStatus, " +
                    "Deadline from JobTicket inner join Customer on JobTicket.CustomerID = Customer.CustomerID WHERE " +
                    "TicketStatus = 'Incomplete' order by Deadline"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = sqlConnect;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            grdvwNotifications.DataSource = dt;
                            grdvwNotifications.DataBind();
                        }
                    }
                }
            }
        }

        // Row Command for notification gridview
        protected void grdvwNotifications_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "View")
            {
                // Saves selected Row as index 'row'    then can use row.Cells[whatever column you want to select] to bind to whatever                
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = grdvwNotifications.Rows[index];

                // Binding Gridview Column fields to session variables
                Session["CustomerID"] = row.Cells[0].Text;
                Session["CustomerName"] = row.Cells[1].Text;
                Session["Email"] = row.Cells[2].Text;
                Session["PhoneNumber"] = row.Cells[3].Text;
                Session["Address"] = row.Cells[4].Text;
                Session["InitialContactDate"] = row.Cells[5].Text;


                // server.transfer like response.redirect but saves info moving over to other page i think...
                Server.Transfer("CustomerLandingPage.aspx");

            }

            //protected void grdvwNotifications_RowEditing(object sender, GridViewEditEventArgs e)
            //{
            //    grdvwNotifications.EditIndex = e.NewEditIndex;
            //    BindGridView();
            //}

            //protected void grdvwNotifications_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
            //{
            //    grdvwNotifications.EditIndex = -1;
            //    BindGridView();
            //}

            //protected void grdvwNotifications_RowUpdating(object sender, GridViewUpdateEventArgs e)
            //{
            //    GridViewRow row = grdvwNotifications.Rows[e.RowIndex];
            //    int jobTicketID = Convert.ToInt32(grdvwNotifications.DataKeys[e.RowIndex].Value.ToString());
            //    string customerName = (row.Cells[1].Controls[0] as TextBox).Text;
            //    string ticketTitle = (row.Cells[2].Controls[0] as TextBox).Text;
            //    string ticketStatus = (row.Cells[3].Controls[0] as TextBox).Text;
            //    string deadline = (row.Cells[4].Controls[0] as TextBox).Text;

            //    SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            //    {
            //        using (SqlCommand cmd = new SqlCommand("UPDATE JobTicket SET TicketTitle = @TicketTitle, TicketStatus = @TicketStatus, Deadline = @Deadline WHERE JobTicketID = @JobTicketID"))
            //        {
            //            cmd.Parameters.AddWithValue("@JobTicketID", jobTicketID);
            //            cmd.Parameters.AddWithValue("@TicketTitle", ticketTitle);
            //            cmd.Parameters.AddWithValue("@TicketStatus", ticketStatus);
            //            cmd.Parameters.AddWithValue("@Deadline", deadline);

            //            cmd.Connection = sqlConnect;
            //            sqlConnect.Open();
            //            cmd.ExecuteNonQuery();
            //            sqlConnect.Close();
            //        }
            //    }
            //    grdvwNotifications.EditIndex = -1;
            //    this.BindGridView();
            //}
        }


        protected void ViewCustomer_Click(object sender, EventArgs e) 
        {
            // Needs to be updated to go to SPECIFIC customer's Landing Page
            Response.Redirect("CustomerLandingPage.aspx");
        }




        // Onclick for AuctionPickup
        protected void btnAuctionPickup_Click(object sender, EventArgs e) 
        {
            Response.Redirect("AuctionPickup.aspx");
        }

        // the 'OnClick' Method handlers that perform some action when they are activated by the user clicking a button
        protected void btnWarehouseView_Click(object sender, EventArgs e)
        {
            // redirect to Point of Contact Form page 
            Response.Redirect("WarehouseView.aspx");
        }

        protected void btnInitialContact_Click(object sender, EventArgs e)
        {
            // redirect to Point of Contact Form page 
            Response.Redirect("PointOfContactForm.aspx");
        }

        protected void BtnServiceOrder_Click(object sender, EventArgs e)
        {
            Response.Redirect("ServiceOrderForm.aspx");
        }

        protected void btnScheduleMove_Click(object sender, EventArgs e)
        {
        }

        protected void btnNotificationPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("Notification.aspx");
        }

        

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Login.aspx?loggedout=true");
        }

        
    }
}