﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class AuctionPickup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGridView();
            }
        }

        protected void btnPopulate_Click(object sender, EventArgs e)
        {
            txtBring.Text = "02/17/20";
            txtPickup.Text = "02/19/20";
            txtLook.Text = "02/20/20";
            txtAppraisal.Text = "02/23/20";
            txtSale.Text = "02/26/20";
            rblStorage.Text = "No";
            txtStorage.Text = "77 Blueberry Rd";
            radioButtonCosignee.Text = "Yes";

        }

        protected void btnHome_Click(object sender, EventArgs e) 
        {
            Response.Redirect("Home.aspx");
        }


        public static List<string> GetList(string prefixText, int count)
        {
            return AutoFillCustomerInfo(prefixText);
        }

        private static List<String> AutoFillCustomerInfo(string prefixText)
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            using (SqlCommand com = new SqlCommand())
            {
                com.CommandText = "select CustomerName from Customer where CustomerName LIKE '% @Search %'";


                com.Parameters.AddWithValue("@Search", prefixText);
                com.Connection = sqlConnect;
                sqlConnect.Open();
                List<string> customerNames = new List<string>();
                using (SqlDataReader sdr = com.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        customerNames.Add(sdr["CustomerName"].ToString());
                    }
                }
                sqlConnect.Close();
                return customerNames;
            }
        }

        private void BindGridView()
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("SELECT AuctionPickupID, " +
                    "CustomerName, " +
                    "BringInDate, PickUpDate, LookAtDate, AppraisalDate, SaleDate, SellingRightAway, " +
                    "StorageLocation, ConsignerLetter from AuctionPickup INNER JOIN Customer ON " +
                    "AuctionPickup.CustomerID = Customer.CustomerID"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = sqlConnect;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            grdvwAuctionPickup.DataSource = dt;
                            grdvwAuctionPickup.DataBind();
                        }
                    }
                }
            }
        }

        private void GetCustomerDetails(string CustomerName)
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            SqlCommand com = new SqlCommand("GetCustomerContactInfo", sqlConnect);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@CustomerName", CustomerName);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            sqlConnect.Close();
            txtPhone.Text = dt.Rows[0]["Phonenumber"].ToString();
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
           // txtDate.Text = dt.Rows[0]["DateOfContact"].ToString();
        }
        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtBring.Text = "";
            txtPickup.Text = "";
            txtLook.Text = "";
            txtAppraisal.Text = "";
            txtSale.Text = "";
            rblStorage.ClearSelection();
            txtStorage.Text = "";
            radioButtonCosignee.ClearSelection();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string bring = txtBring.Text;
            string pickup = txtPickup.Text;
            string look = txtLook.Text;
            string appraisal = txtAppraisal.Text;
            string sale = txtSale.Text;
            string needStorage = rblStorage.SelectedValue.ToString();
            string storageLocation = txtStorage.Text;
            string consignee = radioButtonCosignee.SelectedValue.ToString();

            // Create query for inserting data into the AuctionPickup table
            string sqlAuctionPickupQuery = "INSERT INTO AuctionPickup (BringInDate, PickUpDate, LookAtDate, " +
                "AppraisalDate, SaleDate, SellingRightAway, StorageLocation, ConsignerLetter) VALUES  @BringInDate, @PickupDate, " +
                "@LookAtDate, @AppraisalDate, @SaleDate, @SellingRightAway, @StorageLocation, @ConsignerLetter)";

            // Define connection to the database:
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);

            // Create SQL command object which will send the query
            SqlCommand sqlCommand = new SqlCommand();

            sqlCommand.Parameters.AddWithValue("@BringInDate", bring);
            sqlCommand.Parameters.AddWithValue("@PickUpDate", pickup);
            sqlCommand.Parameters.AddWithValue("@LookAtDate", look);
            sqlCommand.Parameters.AddWithValue("@AppraisalDate", appraisal);
            sqlCommand.Parameters.AddWithValue("@SaleDate", sale);
            sqlCommand.Parameters.AddWithValue("@SellingRightAway", needStorage);
            sqlCommand.Parameters.AddWithValue("@StorageLocation", storageLocation);
            sqlCommand.Parameters.AddWithValue("@ConsignerLetter", consignee);

            sqlCommand.Connection = sqlConnect;
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = sqlAuctionPickupQuery;

            // open connection and send the query
            sqlConnect.Open();
            SqlDataReader queryResults = sqlCommand.ExecuteReader();


            // close connections
            queryResults.Close();
            sqlConnect.Close();
        }

        protected void txtCustomerName_TextChanged(object sender, EventArgs e)
        {
            //callingmethod
            GetCustomerDetails(txtCustomerName.Text);
        }

        protected void grdvwAuctionPickup_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdvwAuctionPickup.EditIndex = e.NewEditIndex;
            BindGridView();
        }

        protected void grdvwAuctionPickup_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdvwAuctionPickup.EditIndex = -1;
            BindGridView();
        }

        protected void grdvwAuctionPickup_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = grdvwAuctionPickup.Rows[e.RowIndex];
            int auctionPickupID = Convert.ToInt32(grdvwAuctionPickup.DataKeys[e.RowIndex].Value.ToString());
            string bringInDate = (row.Cells[2].Controls[0] as TextBox).Text;
            string pickUpDate = (row.Cells[3].Controls[0] as TextBox).Text;
            string lookAtDate = (row.Cells[4].Controls[0] as TextBox).Text;
            string appraisalDate = (row.Cells[5].Controls[0] as TextBox).Text;
            string saleDate = (row.Cells[6].Controls[0] as TextBox).Text;
            string sellingRightAway = (row.Cells[7].Controls[0] as TextBox).Text;
            string storageLocation = (row.Cells[8].Controls[0] as TextBox).Text;
            string consignerLetter = (row.Cells[9].Controls[0] as TextBox).Text;


            // Define connection to the database:
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);

            using (SqlCommand cmd = new SqlCommand("UPDATE AuctionPickup SET  BringInDate = @BringInDate, " +
                "PickUpDate = @PickUpDate, LookAtDate = @LookAtDate, AppraisalDate = @AppraisalDate, " +
                "SaleDate = @SaleDate, SellingRightAway = @SellingRightAway, StorageLocation = @StorageLocation, " +
                "ConsignerLetter = @ConsignerLetter WHERE AuctionPickupID = @AuctionPickupID"))

            {
                cmd.Parameters.AddWithValue("@AuctionPickupID", auctionPickupID);
                cmd.Parameters.AddWithValue("@BringInDate", bringInDate);
                cmd.Parameters.AddWithValue("@PickUpDate", pickUpDate);
                cmd.Parameters.AddWithValue("@LookAtDate", lookAtDate);
                cmd.Parameters.AddWithValue("@AppraisalDate", appraisalDate);
                cmd.Parameters.AddWithValue("@SaleDate", saleDate);
                cmd.Parameters.AddWithValue("@SellingRightAway", sellingRightAway);
                cmd.Parameters.AddWithValue("@StorageLocation", storageLocation);
                cmd.Parameters.AddWithValue("@ConsignerLetter", consignerLetter);

                cmd.Connection = sqlConnect;
                sqlConnect.Open();
                cmd.ExecuteNonQuery();
                sqlConnect.Close();
            }
            grdvwAuctionPickup.EditIndex = -1;
            this.BindGridView();
        }
    }
}