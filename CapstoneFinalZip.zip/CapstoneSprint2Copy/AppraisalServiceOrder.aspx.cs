﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;



namespace CapstoneSprint2Copy
{
    public partial class AppraisalServiceOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListOfData();
            }
            if (this.Page.PreviousPage != null)
            {
                string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM AppraisalServiceOrder INNER JOIN Customer ON AppraisalServiceOrder.CustomerID = Customer.CustomerID WHERE AppraisalServiceOrder.CustomerID = @id", con);

                SqlCommand cmd2 = new SqlCommand("SELECT Customer.Note FROM Customer WHERE CustomerID = @id", con);

                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                txtCustomerName.Text = Session["CustomerName"].ToString();
                txtPhone.Text = Session["PhoneNumber"].ToString();
                txtEmail.Text = Session["Email"].ToString();
                txtDate.Text = Session["InitialContactDate"].ToString();

                cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                cmd2.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    rdoAppPurpose.SelectedValue = dr["AppraisalPurpose"].ToString();
                    rdoDeadline.SelectedValue = dr["HaveDeadline"].ToString();
                    txtDeadline.Text = dr["Deadline"].ToString();
                    txtAppraisalSize.Text = dr["AppraisalSize"].ToString();
                    txtInventory.Text = dr["Inventory"].ToString();
                }
                dr.Close();
                SqlDataReader dr2 = cmd2.ExecuteReader();

                // Data reader from SQL Queries
                while (dr2.Read())
                {
                    txtNoteContents.Text = Server.HtmlDecode(dr2["Note"].ToString());
                    txtNoteContents.Text = txtNoteContents.Text.Replace("<p>", "");
                }
                dr2.Close();
                con.Close();
            }
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            // For uploading a file
            if (FileUpload.HasFile)
            {
                string FileName = FileUpload.FileName;

                // File is saved  
                FileUpload.PostedFile.SaveAs(Server.MapPath("~/MyUploads/") + FileName);
            }
            ListOfData();
        }

        protected void btnMoveAssessment_Click(object sender, EventArgs e)
        {

        }

        protected void btnAuctionAssessment_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
            //Used to fetch the file from the folder
            Response.TransmitFile(Server.MapPath("~/MyUploads/") + e.CommandArgument);
            Response.End();
        }
        private void ListOfData()
        {
            // Create a datatable
            DataTable dt = new DataTable();
            // Add Columns with the Same name as the Eval Expression and the DataField of the Gridview  
            dt.Columns.Add("File");
            dt.Columns.Add("Size");
            dt.Columns.Add("Type");
            // Loop through Each file available in the folder  
            foreach (string str in Directory.GetFiles(Server.MapPath("~/MyUploads")))
            {
                FileInfo fileinfo = new FileInfo(str);
                //Get the name of the File  
                string filename = fileinfo.Name;
                string filesize = (fileinfo.Length / 1024).ToString();
                string filetype = GetFileTypeByFileExtension(fileinfo.Extension);
                // Add Rows to the DataTable  
                dt.Rows.Add(filename, filesize, filetype);
            }
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        private string GetFileTypeByFileExtension(string fileExtention)
        {
            switch (fileExtention.ToLower())
            {
                case ".doc":
                case ".docx":
                    return "Microsoft Word Document";
                case ".xls":
                case ".xlsx":
                    return "Microsoft Excel Document";
                case ".txt":
                    return "Text File";
                case ".png":
                case ".jpg":
                    return "Windows Image file";
                default:
                    return "Unknown file type";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string appraisalPurpose = rdoAppPurpose.SelectedValue.ToString();
            string haveDeadline = rdoDeadline.Text;
            string deadline = txtDeadline.Text;
            string appraisalSize = txtAppraisalSize.Text;
            string inventory = txtInventory.Text;

            // Create query for inserting data into the AuctionPickup table
            string sqlAuctionPickupQuery = "INSERT INTO AppraisalServiceOrder (AppraisalPurpose, HaveDeadline, " +
                "Deadline, AppraisalSize, Inventory, CustomerID) VALUES  (@AppraisalPurpose, @HaveDeadline, @Deadline, " +
                "@AppraisalSize, @Inventory, @id)";

            // Define connection to the database:
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);

            // Create SQL command object which will send the query
            SqlCommand sqlCommand = new SqlCommand();

            sqlCommand.Parameters.AddWithValue("@AppraisalPurpose", appraisalPurpose);
            sqlCommand.Parameters.AddWithValue("@HaveDeadline", haveDeadline);
            sqlCommand.Parameters.AddWithValue("@Deadline", deadline);
            sqlCommand.Parameters.AddWithValue("@AppraisalSize", appraisalSize);
            sqlCommand.Parameters.AddWithValue("@Inventory", inventory);
            sqlCommand.Parameters.AddWithValue("@id", hiddenCustomerID.Text);

            sqlCommand.Connection = sqlConnect;
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.CommandText = sqlAuctionPickupQuery;

            // open connection and send the query
            sqlConnect.Open();
            SqlDataReader queryResults = sqlCommand.ExecuteReader();


            // close connections
            queryResults.Close();
            sqlConnect.Close();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "UPDATE AppraisalServiceOrder SET AppraisalPurpose = @AppraisalPurpose, HaveDeadline = @HaveDeadline, Deadline = @Deadline, AppraisalSize = @AppraisalSize, Inventory = @Inventory WHERE CustomerID = @id";
            String query2 = "UPDATE Customer SET Note = @note Where CustomerID = " + hiddenCustomerID.Text + "";

            SqlCommand command = new SqlCommand(query1, sqlConnect);

            sqlConnect.Open();

            adapter.UpdateCommand = new SqlCommand(query1, sqlConnect);
            adapter.UpdateCommand.Parameters.AddWithValue("@AppraisalPurpose", HttpUtility.HtmlEncode(rdoAppPurpose.SelectedValue.ToString()));
            adapter.UpdateCommand.Parameters.AddWithValue("@HaveDeadline", HttpUtility.HtmlEncode(rdoDeadline.SelectedValue.ToString()));
            adapter.UpdateCommand.Parameters.AddWithValue("@Deadline", HttpUtility.HtmlEncode(txtDeadline.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@AppraisalSize", HttpUtility.HtmlEncode(txtAppraisalSize.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@Inventory", HttpUtility.HtmlEncode(txtInventory.Text));
            adapter.UpdateCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));
            adapter.UpdateCommand.ExecuteNonQuery();

            adapter.UpdateCommand = new SqlCommand(query2, sqlConnect);
            adapter.UpdateCommand.Parameters.AddWithValue("@note", HttpUtility.HtmlEncode(txtNoteContents.Text));
            adapter.UpdateCommand.ExecuteNonQuery();


            command.Dispose();
            sqlConnect.Close();
        }
    }
}