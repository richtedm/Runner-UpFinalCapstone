﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class AuctionPreAssess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Page.PreviousPage != null)
            {
                string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM AuctionPreAssessment INNER JOIN Customer ON AuctionPreAssessment.CustomerID = Customer.CustomerID WHERE AuctionPreAssessment.CustomerID = @id", con);

                SqlCommand cmd2 = new SqlCommand("SELECT Customer.Note FROM Customer WHERE CustomerID = @id", con);

                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                txtName.Text = Session["CustomerName"].ToString();
                txtPhone.Text = Session["PhoneNumber"].ToString();
                txtEmail.Text = Session["Email"].ToString();
                txtDate.Text = Session["InitialContactDate"].ToString();

                cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                cmd2.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    txtSell.Text = dr["Sell"].ToString();
                    ddlWhy.SelectedItem.Text = dr["Why"].ToString();
                    txtMoveDate.Text = dr["MoveDate"].ToString();
                    ddlWalk.SelectedItem.Text = dr["WalkInfo"].ToString();
                    tbTD.Text = dr["TrashDesc"].ToString();
                    if (dr["Photo"].Equals("Yes"))
                    {
                        cbPhoto.Checked = true;
                    }
                    else
                    {
                        cbPhoto.Checked = false;
                    }

                    if (dr["Items"].Equals("Yes"))
                    {
                        cbItems.Checked = true;
                    }
                    else
                    {
                        cbItems.Checked = false;
                    }

                    if (dr["Bring"].Equals("Yes"))
                    {
                        cbBring.Checked = true;
                    }
                    else
                    {
                        cbBring.Checked = false;
                    }
                    if (dr["Walk"].Equals("Yes"))
                    {
                        cbWalk.Checked = true;
                        ddlWalkdiv.Visible = true;
                    }
                    else
                    {
                        cbWalk.Checked = false;
                    }
                    if (dr["Pickup"].Equals("Yes"))
                    {
                        cbPickup.Checked = true;
                    }
                    else
                    {
                        cbPickup.Checked = false;
                    }
                    if (dr["Trash"].Equals("Yes"))
                    {
                        cbTrash.Checked = true;
                        tbTDdiv.Visible = true;
                    }
                    else
                    {
                        cbTrash.Checked = false;
                    }
                    if (dr["Moving"].Equals("Yes"))
                    {
                        cbMove.Checked = true;
                    }
                    else
                    {
                        cbMove.Checked = false;
                    }
                    if (dr["Appraisal"].Equals("Yes"))
                    {
                        cbAppraisal.Checked = true;
                    }
                    else
                    {
                        cbAppraisal.Checked = false;


                    }
                }

                dr.Close();
                SqlDataReader dr2 = cmd2.ExecuteReader();

                // Data reader from SQL Queries
                while (dr2.Read())
                {
                    txtNoteContents.Text = Server.HtmlDecode(dr2["Note"].ToString());
                    txtNoteContents.Text = txtNoteContents.Text.Replace("<p>", "");
                }


                dr2.Close();
                con.Close();



            }
        }
        protected void cbWalk_CheckedChanged(object sender, EventArgs e)
        {
            if (cbWalk.Checked)
            {
                ddlWalkdiv.Visible = true;
            }
            else
            {
                ddlWalkdiv.Visible = false;
            }
        }
        protected void cbTrash_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTrash.Checked == true)
            {
                tbTDdiv.Visible = true;
            }
            else { tbTDdiv.Visible = false; }
        }
        protected void btPart2_Click(object sender, EventArgs e)
        {
            String why = ddlWhy.SelectedIndex.ToString();
            String photo = "No";
            String item = "No";
            String bring = "No";
            String walk = "No";
            String walkInfo = ddlWalk.SelectedIndex.ToString();
            String pickup = "No";
            String trash = "No";
            String move = "No";
            String appraisal = "No";
            if (cbPhoto.Checked)
            {
                photo = "Yes";
            }
            if (cbItems.Checked)
            {
                item = "Yes";
            }
            if (cbBring.Checked)
            {
                bring = "Yes";
            }
            if (cbWalk.Checked)
            {
                walk = "Yes";
            }
            if (cbPickup.Checked)
            {
                pickup = "Yes";
            }
            if (cbTrash.Checked)
            {
                trash = "Yes";
            }
            if (cbMove.Checked)
            {
                move = "Yes";
            }
            if (cbAppraisal.Checked)
            {
                appraisal = "Yes";
            }
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);
            String query1 = "Insert into AuctionPreAssessment(Sell, Why, MoveDate, Photo, Items, Bring, Walk, WalkInfo, Pickup, Trash, TrashDesc, Moving, Appraisal, CustomerID) VALUES(@Sell, @Why, @MoveDate, @Photo, @Items, @Bring, @Walk, @WalkInfo, @Pickup, @Trash, @TrashDesc, @Moving, @Appraisal, @id)";
            SqlCommand command = new SqlCommand(query1, sqlConnect);
            sqlConnect.Open();

            adapter.InsertCommand = new SqlCommand(query1, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@Sell", HttpUtility.HtmlEncode(txtSell.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Why", HttpUtility.HtmlEncode(why));
            adapter.InsertCommand.Parameters.AddWithValue("@MoveDate", HttpUtility.HtmlEncode(txtMoveDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Photo", HttpUtility.HtmlEncode(photo));
            adapter.InsertCommand.Parameters.AddWithValue("@Items", HttpUtility.HtmlEncode(item));
            adapter.InsertCommand.Parameters.AddWithValue("@Bring", HttpUtility.HtmlEncode(bring));
            adapter.InsertCommand.Parameters.AddWithValue("@Walk", HttpUtility.HtmlEncode(walk));
            adapter.InsertCommand.Parameters.AddWithValue("@WalkInfo", HttpUtility.HtmlEncode(walkInfo));
            adapter.InsertCommand.Parameters.AddWithValue("@Pickup", HttpUtility.HtmlEncode(pickup));
            adapter.InsertCommand.Parameters.AddWithValue("@Trash", HttpUtility.HtmlEncode(trash));
            adapter.InsertCommand.Parameters.AddWithValue("@TrashDesc", HttpUtility.HtmlEncode(tbTD.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Moving", HttpUtility.HtmlEncode(move));
            adapter.InsertCommand.Parameters.AddWithValue("@Appraisal", HttpUtility.HtmlEncode(appraisal));
            adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            sqlConnect.Close();

        }
    }
}