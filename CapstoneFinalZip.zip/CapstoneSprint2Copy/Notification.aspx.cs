﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class Notification : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["UserName"] != null)
            //{


            //}
            //else
            //{
            //    Session["InvalidUse"] = "You must first login to access the home page!";
            //    Response.Redirect("Login.aspx");

            //}

            if (!this.IsPostBack)
            {
                this.BindGridView();
            }
        }

        private void BindGridView()
        {
            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("select JobTicketID, TicketTitle, TicketStatus, Deadline from JobTicket WHERE TicketStatus = 'Incomplete'"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = sqlConnect;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            grdvwNotifications.DataSource = dt;
                            grdvwNotifications.DataBind();
                        }
                    }
                }
            }
        }

        protected void BtnHome_Click(object sender, EventArgs e) 
        {
            Response.Redirect("Home.aspx");
        }

        protected void grdvwNotifications_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdvwNotifications.EditIndex = e.NewEditIndex;
            BindGridView();
        }

        protected void grdvwNotifications_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdvwNotifications.EditIndex = -1;
            BindGridView();
        }

        protected void grdvwNotifications_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = grdvwNotifications.Rows[e.RowIndex];
            int jobTicketID = Convert.ToInt32(grdvwNotifications.DataKeys[e.RowIndex].Value.ToString());
            string ticketTitle = (row.Cells[1].Controls[0] as TextBox).Text;
            string ticketStatus = (row.Cells[2].Controls[0] as TextBox).Text;
            string deadline = (row.Cells[3].Controls[0] as TextBox).Text;

            SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE JobTicket SET TicketTitle = @TicketTitle, TicketStatus = @TicketStatus, Deadline = @Deadline WHERE JobTicketID = @JobTicketID"))
                {
                    cmd.Parameters.AddWithValue("@JobTicketID", jobTicketID);
                    cmd.Parameters.AddWithValue("@TicketTitle", ticketTitle);
                    cmd.Parameters.AddWithValue("@TicketStatus", ticketStatus);
                    cmd.Parameters.AddWithValue("@Deadline", deadline);

                    cmd.Connection = sqlConnect;
                    sqlConnect.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnect.Close();
                }
            }
            grdvwNotifications.EditIndex = -1;
            this.BindGridView();
        }
    }
}