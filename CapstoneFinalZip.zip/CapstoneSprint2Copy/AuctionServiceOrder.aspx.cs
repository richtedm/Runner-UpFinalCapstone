﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class AuctionServiceOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Page.PreviousPage != null)
            {
                string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM AuctionServiceOrder INNER JOIN Customer ON AuctionServiceOrder.CustomerID = Customer.CustomerID WHERE AuctionServiceOrder.CustomerID = @id", con);
                SqlCommand cmd2 = new SqlCommand("SELECT * FROM AuctionAssessment INNER JOIN Customer ON AuctionAssessment.CustomerID = Customer.CustomerID WHERE AuctionAssessment.CustomerID = @id", con);
                SqlCommand cmd3 = new SqlCommand("SELECT * FROM AuctionPreAssessment INNER JOIN Customer ON AuctionPreAssessment.CustomerID = Customer.CustomerID WHERE AuctionPreAssessment.CustomerID = @id", con);
                SqlCommand cmd4 = new SqlCommand("SELECT * FROM AuctionServiceOrder INNER JOIN Customer ON AuctionServiceOrder.CustomerID = Customer.CustomerID WHERE AuctionServiceOrder.CustomerID = @id", con);


                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                txtCustomerName.Text = Session["CustomerName"].ToString();
                txtPhone.Text = Session["PhoneNumber"].ToString();
                txtEmail.Text = Session["Email"].ToString();
                txtDate.Text = Session["InitialContactDate"].ToString();

                cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                cmd2.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                cmd3.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                cmd4.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txtCrew.Text = dr["CrewMemeber"].ToString();
                    txtAddress2.Text = dr["Address"].ToString();
                    txtMen.Text = dr["NumOfEmployees"].ToString();
                    txtCharge.Text = dr["Cost"].ToString();
                }
                dr.Close();

                dr = cmd2.ExecuteReader();
                while (dr.Read())
                {
                    txtSmall.Text = dr["SmBox"].ToString();
                    txtMed.Text = dr["MdBox"].ToString();
                    txtLarge.Text = dr["LgBox"].ToString();
                    txtArt.Text = dr["Art"].ToString();
                    txtSPad.Text = dr["SmPads"].ToString();
                    txtLPad.Text = dr["LgPads"].ToString();
                    txtHome.Text = dr["Residence"].ToString();
                    txtAccess.Text = dr["TruckAccess"].ToString();
                    txtFar.Text = dr["WalkToDoor"].ToString();
                    txtStep.Text = dr["StepsToHouse"].ToString();
                    txtTrucks.Text = dr["Trucks"].ToString();
                    if (dr["NeedApplianceCart"].Equals("yes"))
                    {
                        cbAppliance.Checked = true;
                    }
                    else 
                    {
                        cbAppliance.Checked = false;
                    }
                    if (dr["NeedPianoDolly"].Equals("yes"))
                    {
                        cbPDolly.Checked = true;
                    }
                    else
                    {
                        cbPDolly.Checked = false;
                    }
                    if (dr["NeedPianoBoard"].Equals("yes"))
                    {
                        cbPBoard.Checked = true;
                    }
                    else
                    {
                        cbPBoard.Checked = false;
                    }
                    if (dr["NeedGunCart"].Equals("yes"))
                    {
                        cbGun.Checked = true;
                    }
                    else
                    {
                        cbGun.Checked = false;
                    }
                    if (dr["NeedExtraBlankets"].Equals("yes"))
                    {
                        cbBlankets.Checked = true;
                    }
                    else
                    {
                        cbBlankets.Checked = false;
                    }
                    
                }
                dr.Close();



                dr = cmd3.ExecuteReader();
                while (dr.Read())
                {
                    txtTrash.Text = dr["TrashDesc"].ToString();
                    
                }
                dr.Close();







                con.Close();
            }
        }
        protected void btAddCrew_Click(object sender, EventArgs e)
        {
            String emp = txtCrew.Text;
            emp += ddlPackCrew.SelectedValue.Trim() + ", ";
            txtCrew.Text = emp;
        }

        protected void btAddCrew2_Click(object sender, EventArgs e)
        {
            //String emp = txtCrew2.Text;
            //emp += ddlCrew2.SelectedValue.Trim() + ", ";
            //txtCrew2.Text = emp;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }
    }
}