﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class CustomerLandingPage : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Page.PreviousPage != null)
            {


                string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();


                SqlCommand cmd = new SqlCommand("SELECT CustomerID, Note FROM Customer WHERE CustomerID = @id", con);



                //Retrieve values from Session Variables
                //Response.Write("CustomerID: " + Session["CustomerID"].ToString() + "<br />");
                //Response.Write("CustomerName: " + Session["CustomerName"].ToString() + "<br />");
                //Response.Write("Email: " + Session["Email"].ToString() + "<br />");
                //Response.Write("PhoneNumber: " + Session["PhoneNumber"].ToString() + "<br />");


                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                CustomerNameLbl.Text = Session["CustomerName"].ToString();
                txtPopupCustomerName.Text = Session["CustomerName"].ToString();
                emailLbl.Text = Session["Email"].ToString();
                PhonenumberLbl.Text = Session["PhoneNumber"].ToString();
                AddressLbl.Text = Session["Address"].ToString();
                DateOfInitialContactlbl.Text = Session["InitialContactDate"].ToString();



                cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                SqlDataReader dr = cmd.ExecuteReader();


                // Data reader from SQL Queries
                while (dr.Read())
                {
                    txtNoteContents.Text = Server.HtmlDecode(dr["Note"].ToString());
                    txtNoteContents.Text = txtNoteContents.Text.Replace("<p>", "");
                }


                dr.Close();
                con.Close();






            }
        }


        protected void btnSubmit_Click(object sender, EventArgs e)
        {
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlConnection sqlConnect = new SqlConnection(WebConfigurationManager.ConnectionStrings["Capstone"].ConnectionString);
        string str = "";
        string deadline = txtDeadline.Text;
        for (int i = 0; i <= cblServiceNeeded.Items.Count - 1; i++)
        {
            if (cblServiceNeeded.Items[i].Selected)
            {
                if (str == "")
                {
                    str = cblServiceNeeded.Items[i].Text;
                }
                else
                {
                    str += "," + cblServiceNeeded.Items[i].Text;
                }
            }
        }
            string serviceQuery = "INSERT INTO JobTicket(TicketTitle, Deadline, " +
                "NeedAuction, NeedAppraisal, NeedMove, CustomerID) VALUES (@TicketTitle, " +
                "@Deadline, @NeedAuction, @NeedAppraisal, @NeedMove, @id)";
            SqlCommand command = new SqlCommand(serviceQuery, sqlConnect);
            sqlConnect.Open();
            //Parameterized Queries For Customer Table
            adapter.InsertCommand = new SqlCommand(serviceQuery, sqlConnect);
            adapter.InsertCommand.Parameters.AddWithValue("@TicketTitle", HttpUtility.HtmlEncode(txtTicketTitle.Text));
         //   adapter.InsertCommand.Parameters.AddWithValue("@ServicesNeeded", HttpUtility.HtmlEncode(str));
         //   adapter.InsertCommand.Parameters.AddWithValue("@TicketOpenDate", HttpUtility.HtmlEncode(txtOpenDate.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@Deadline", HttpUtility.HtmlEncode(txtDeadline.Text));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedAuction", HttpUtility.HtmlEncode(cblServiceNeeded.Items[0].Selected));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedAppraisal", HttpUtility.HtmlEncode(cblServiceNeeded.Items[1].Selected));
            adapter.InsertCommand.Parameters.AddWithValue("@NeedMove", HttpUtility.HtmlEncode(cblServiceNeeded.Items[2].Selected));
            adapter.InsertCommand.Parameters.AddWithValue("@id", HttpUtility.HtmlEncode(hiddenCustomerID.Text));

            //    adapter.InsertCommand.Parameters.AddWithValue("@NeedConsignment", HttpUtility.HtmlEncode(cblServiceNeeded.Items[3].Selected));
            adapter.InsertCommand.ExecuteNonQuery();
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {

        }


        protected void btnAppraisalServiceOrder_Click(object sender, EventArgs e)
        {
            Server.Transfer("AppraisalServiceOrder.aspx");
        }




        protected void AuctionPreAssess_Click(object sender, EventArgs e)
        {
            Server.Transfer("AuctionPreAssessment.aspx");
        }
        

        protected void UpdateCustomerBtn_Click(object sender, EventArgs e) 
        {
            Server.Transfer("UpdateCustomer.aspx");
        }

        protected void ReturnHomeBtn_Click(object sender, EventArgs e)
        {
            Server.Transfer("Home.aspx");
        }



        // Navigation to Forms and Stuff
        protected void moveServiceOrderBtn_Click(object sender, EventArgs e) 
        {
            Server.Transfer("MoveServiceOrder.aspx");
        }

        protected void moveAssessmentBtn_Click(object sender, EventArgs e) 
        {
            Server.Transfer("MoveAssessment.aspx");
        }
        //pre
        protected void movePreAssessmentBtn_Click(object sender, EventArgs e)
        {
            Server.Transfer("MovePreAssessment.aspx");
        }

        protected void auctionServiceOrderBtn_Click(object sender, EventArgs e)
        {
            Server.Transfer("AuctionServiceOrder.aspx");
        }

        protected void auctionAssessmentBtn_Click(object sender, EventArgs e)
        {
            Server.Transfer("AuctionAssessment.aspx");
        }
        //pre
        protected void auctionPreAssessmentBtn_Click(object sender, EventArgs e)
        {
            Server.Transfer("AuctionPreAssess.aspx");
        }

        protected void appraisalBtn_Click(object sender, EventArgs e)
        {
            Server.Transfer("AppraisalForm.aspx");
        }



        protected void updateNoteBtn_Click(object sender, EventArgs e) 
        {
            SqlDataAdapter adapter = new SqlDataAdapter();
            string connectionString = WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
            SqlConnection sqlConnect = new SqlConnection(connectionString);

            SqlCommand command = new SqlCommand("UPDATE Customer SET Note = @note WHERE CustomerID = " + hiddenCustomerID.Text + "", sqlConnect);

            sqlConnect.Open();

            //Parameterized Queries
            adapter.UpdateCommand = command;
            adapter.UpdateCommand.Parameters.AddWithValue("@note", HttpUtility.HtmlEncode(txtNoteContents.Text));
            adapter.UpdateCommand.ExecuteNonQuery();

            // Close Connection
            command.Dispose();
            sqlConnect.Close();
        }





    }
}