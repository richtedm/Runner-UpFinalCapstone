﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class CustomerLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString.Get("loggedout") == "true")
            {
                lblStatus.ForeColor = Color.Green;
                lblStatus.Font.Bold = false;
                lblStatus.Text = "User has successfully logged out!";
            }
            if (Session["InvalidUse"] != null)
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Font.Bold = false;
                lblStatus.Text = Session["InvalidUse"].ToString();
            }
        }
        protected void btnCustomerLogin_Click(object sender, EventArgs e)
        {
            SqlConnection dbConnection = new SqlConnection(WebConfigurationManager.ConnectionStrings["AUTH"].ConnectionString.ToString());

            dbConnection.Open();

            SqlCommand findPass = new SqlCommand();

            findPass.Connection = dbConnection;
            findPass.CommandText = "SELECT PasswordHash FROM Pass WHERE Username = @Username";
            findPass.Parameters.Add(new SqlParameter("@Username", HttpUtility.HtmlEncode(txtUsername.Text)));

            SqlDataReader reader = findPass.ExecuteReader();
            SqlCommand loginCommand = new SqlCommand();

            // Properties for the loginCommand object
            loginCommand.Connection = dbConnection;
            loginCommand.CommandType = CommandType.StoredProcedure;
            loginCommand.CommandText = "JeremyEzellLab3";

            loginCommand.Parameters.AddWithValue("@UserName", HttpUtility.HtmlEncode(txtUsername.Text));

            SqlDataReader loginResults = loginCommand.ExecuteReader();





            if (reader.HasRows)
            {
                while (reader.Read() && loginResults.Read())
                {
                    string storedHash = reader["PasswordHash"].ToString();

                    if (PasswordHash.ValidatePassword(HttpUtility.HtmlEncode(txtPassword.Text), storedHash))
                    {
                        Session["UserName"] = HttpUtility.HtmlEncode(txtUsername.Text);
                        Response.Redirect("CustomerPortal.aspx");
                    }
                    else
                        lblStatus.Text = "Password is wrong, please try again";
                }
            }
            else

            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Font.Bold = true;
                lblStatus.Text = "Either Username and/or Password are incorrect, please try again!";


            }

            dbConnection.Close();

        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            // redirect to Intro page
            Response.Redirect("Login.aspx");
        }

        protected void btnCreateAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateCustAccount.aspx");
        }

        
    }
}