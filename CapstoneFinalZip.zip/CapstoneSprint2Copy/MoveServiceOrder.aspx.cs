﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneSprint2Copy
{
    public partial class MoveServiceOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (this.Page.PreviousPage != null)
            {
                string connectionString =
                WebConfigurationManager.ConnectionStrings["Capstone"].ToString();
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM MoveServiceOrder INNER JOIN Customer ON MoveServiceOrder.CustomerID = Customer.CustomerID WHERE MoveServiceOrder.CustomerID = @id", con);
                SqlCommand cmd2 = new SqlCommand("SELECT * FROM MoveAssessment INNER JOIN Customer ON MoveAssessment.CustomerID = Customer.CustomerID WHERE MoveAssessment.CustomerID = @id", con);
                SqlCommand cmd3 = new SqlCommand("SELECT * FROM MovePreAssessment INNER JOIN Customer ON MovePreAssessment.CustomerID = Customer.CustomerID WHERE MovePreAssessment.CustomerID = @id", con);
                SqlCommand cmd4 = new SqlCommand("SELECT * FROM MoveServiceOrder INNER JOIN Customer ON MoveServiceOrder.CustomerID = Customer.CustomerID WHERE MoveServiceOrder.CustomerID = @id", con);


                hiddenCustomerID.Text = Session["CustomerID"].ToString();
                txtName.Text = Session["CustomerName"].ToString();
                txtPhone.Text = Session["PhoneNumber"].ToString();

                cmd.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                //cmd2.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                //cmd3.Parameters.AddWithValue("@id", hiddenCustomerID.Text);
                //cmd4.Parameters.AddWithValue("@id", hiddenCustomerID.Text);

                //SqlDataReader dr = cmd.ExecuteReader();
                //while (dr.Read())
                //{
                //    txtAddress.Text = dr["Address1"].ToString();
                //    txtToAddress.Text = dr["Address2"].ToString();
                //    txtMen.Text = dr["NumOfEmployees"].ToString();
                //    txtCharge.Text = dr["Cost"].ToString();
                //    txtCosts.Text = dr["MCost"].ToString();


                //}
                //dr.Close();

                //dr = cmd2.ExecuteReader();
                //while (dr.Read())
                //{
                //    txtHome.Text = dr["Residence"].ToString();
                //    txtAccess.Text = dr["TruckAccess"].ToString();
                //    txtFar.Text = dr["WalkToDoor"].ToString();
                //    txtStep.Text = dr["StepsToHouse"].ToString();
                //    txtTrucks.Text = dr["Trucks"].ToString();
                //    if (dr["NeedApplianceCart"].Equals("yes"))
                //    {
                //        cbAppliance.Checked = true;
                //    }
                //    else
                //    {
                //        cbAppliance.Checked = false;
                //    }
                //    if (dr["NeedPianoDolly"].Equals("yes"))
                //    {
                //        cbPDolly.Checked = true;
                //    }
                //    else
                //    {
                //        cbPDolly.Checked = false;
                //    }
                //    if (dr["NeedPianoBoard"].Equals("yes"))
                //    {
                //        cbPBoard.Checked = true;
                //    }
                //    else
                //    {
                //        cbPBoard.Checked = false;
                //    }
                //    if (dr["NeedGunCart"].Equals("yes"))
                //    {
                //        cbGun.Checked = true;
                //    }
                //    else
                //    {
                //        cbGun.Checked = false;
                //    }
                //    if (dr["NeedExtraBlankets"].Equals("yes"))
                //    {
                //        cbBlankets.Checked = true;
                //    }
                //    else
                //    {
                //        cbBlankets.Checked = false;
                //    }

                //}
                //dr.Close();



                //dr = cmd3.ExecuteReader();
                //while (dr.Read())
                //{
                //    txtTrash.Text = dr["TrashDesc"].ToString();
                //}
                //dr.Close();







                //con.Close();
            }
        }
    }
}
 
